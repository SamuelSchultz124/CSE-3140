import subprocess, hashlib, time

print(f'Start time: {time.time()}')

#path to the file
file_path = '/home/cse/Lab1/Q6'

#Gang members with login info found
completed_members = ['ForestPurpleFalcon522', 'SkyRedFalcon914', 'SkyBlueBear611', 'MountainBlueFalcon157']

with open(f'{file_path}/gang','r') as f:
    gang = f.readlines()

with open(f'{file_path}/SaltedPWs','r') as f:
    SaltedAccs = f.readlines()

with open(f'{file_path}/PwnedPWs100k', 'r') as f:
    PwnedPWs = f.readlines()

#Strip whitespace of gang file
gang = [gangster.strip() for gangster in gang]


#iterate through HashedAccs
for acc in SaltedAccs:
    #Extract username and Hashed pw from Hashed Acc
    username, salt, hashedPW = acc.split(',')
    
    #If the username is a gang member and not already completed
    if username.strip() in gang and username.strip() not in completed_members:
        print(f'User Found!')
        #Iterate  through PW file
        for PW in PwnedPWs:
            #Append two random digits
            for i in range(0, 10):
                Guess = PW.strip() + str(i)
                #Hash our guess password
                h = hashlib.sha256()
                h.update(bytes(salt + Guess, 'utf-8'))
                hashed_guess = h.hexdigest()
                    
                #if our password matches try logging in
                if hashedPW.strip() == hashed_guess:
                    print(f'Hashed Guess Matches!')
                    result = subprocess.run(['python3', 'Logic.pyc', username.strip(), Guess.strip()], capture_output = True, text = True)
                    
                    #if our login was successful
                    print(username, Guess)
                    if 'Login successful' in result.stdout:
                        print(f'Password found {username}, {Guess}')
                        break

print(f'End time: {time.time()}')