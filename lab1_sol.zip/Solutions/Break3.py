import subprocess, time

print(f'Start time: {time.time()}')

#Path to the password file
file_path = '/home/cse/Lab1/Q3'

#Usernames to be used for the password cracking
with open(f'{file_path}/gang','r') as f:
    usernames = f.readlines()

#Passwords to be used for the password cracking
with open(f'{file_path}/PwnedPWs100k', 'r') as f:
    passwords = f.readlines()

for username in usernames:
    for password in passwords:
        #use subprocess to run to attempt login from file Logic.pyc from the same directory

        result = subprocess.run(['python3', 'Login.pyc', username.strip(), password.strip()], capture_output = True, text = True)

        #Check if the login was successful
        if 'Login successful' in result.stdout:
            print(f'Password found {username}, {password}')
            continue

print(f'End time: {time.time()}')