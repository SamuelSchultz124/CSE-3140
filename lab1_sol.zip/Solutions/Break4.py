import subprocess, time

print('Start time:', time.time())

#Path to the password file
file_path = '/home/cse/Lab1/Q4'

#gang members with login info found
completed_members = ['SkyRedFalcon914', 'SkyBlueBear611', 'MountainBlueFalcon157']


#Usernames to be used for the password cracking
with open(f'{file_path}/gang', 'r') as f:
    gang = f.readlines()

with open(f'{file_path}/PwnedPWfile', 'r') as f:
    lines = f.readlines()

for gangster in gang:
    
    #Check if we already found gangster
    if gangster.strip() in completed_members:
        continue
    
    #for line in the found passwords
    for line in lines:
        #extract username and password
        username, password = line.split(',')
        
        #if we found a match
        if gangster.strip() == username.strip():
            #attempt logic
            result = subprocess.run(['python3', 'Login.pyc', username.strip(), password.strip()], capture_output = True, text = True)

            #check if login was successful
            if 'Login successful' in result.stdout:
                print(f'Password found {username}, {password}')
                break

print('End time:', time.time())
