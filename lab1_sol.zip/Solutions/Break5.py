import subprocess, hashlib, time

print(f'Start time: {time.time()}')

#path to the file
file_path = '/home/cse/Lab1/Q5'

#Gang members with login info found
completed_members = ['ForestPurpleFalcon522', 'SkyRedFalcon914', 'SkyBlueBear611', 'MountainBlueFalcon157']

with open(f'{file_path}/gang','r') as f:
    gang = f.readlines()

with open(f'{file_path}/HashedPWs','r') as f:
    HashedAccs = f.readlines()

with open(f'{file_path}/PwnedPWs100k', 'r') as f:
    PwnedPWs = f.readlines()

#Strip whitespace of gang file
gang = [gangster.strip() for gangster in gang]


#iterate through HashedAccs
for acc in HashedAccs:
    #Extract username and Hashed pw from Hashed Acc
    username, hashedPW = acc.split(',')
    
    #If the username is a gang member and not already completed
    if username.strip() in gang and username.strip() not in completed_members:
        #Iterate  through PW file
        for PW in PwnedPWs:
            #Append two random digits
            for i in range(0, 10):
                for j in range(0, 10):
                    Guess = PW.strip() + str(i) + str(j)
                    #Hash our guess password
                    h = hashlib.sha256()
                    h.update(bytes(Guess, 'utf-8'))
                    hashed_guess = h.hexdigest()
                    
                    #if our password matches try logging in
                    if hashedPW.strip() == hashed_guess:
                        result = subprocess.run(['python3', 'Logic.pyc', username.strip(), Guess], capture_output = True, text = True)
                        
                        print(username, Guess)
                        #if our login was successful
                        if 'Login successful' in result.stdout:
                            print(f'Password found {username}, {Guess}')
                            break

print(f'End time: {time.time()}')