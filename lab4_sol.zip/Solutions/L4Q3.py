from flask import Flask, render_template

print("Flask app is starting...")

app = Flask(__name__)

@app.route('/')
def index():
    print("Serving index.html")  
    return render_template('index.html', name='Samuel Schultz')

if __name__ == '__main__':
    print("Running the app...") 
    app.run(debug=True)


