from flask import Flask, render_template, request, redirect, flash, url_for

app = Flask(__name__)
app.secret_key = 'supersecretkey'

users_db = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    users_db.append({'username': username, 'password': password})
    flash("Your credentials have been logged.")
    return redirect("http://127.0.0.1:8080")

@app.route('/management')
def management():
    return render_template('management.html', users=users_db)


if __name__ =='__main__':
    app.run(debug=True)

